## External dependencies

This directory contains dependency code and data loaded directly into the
reposistories.

Keep total file size down to a reasonable amount.

Try to note in the CHANGELOG.md file in each directory
which commit of the external repository was used, and a
summary of edits made.



