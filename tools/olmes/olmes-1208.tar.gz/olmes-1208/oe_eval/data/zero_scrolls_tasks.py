ZERO_SCROLLS_TASKS = [
    "gov_report",
    "summ_screen_fd",
    "qmsum",
    "qasper",
    "narrative_qa",
    "quality",
    # "musique",
    # "squality",
    # "space_digest",
    # "book_sum_sort",
]
